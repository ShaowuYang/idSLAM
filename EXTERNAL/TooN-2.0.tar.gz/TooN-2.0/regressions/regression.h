#include <TooN/TooN.h>
#include <TooN/LU.h>
#include <TooN/SVD.h>
#include <TooN/QR_Lapack.h>
#include <TooN/helpers.h>
#include <TooN/determinant.h>
#include <iomanip>
using namespace std;
using namespace TooN;
